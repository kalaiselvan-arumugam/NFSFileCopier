package com.ks.auth;

import lombok.Data;

@Data
public class AuthRequest {
    private String client_id;
    private String client_secret;
    private String orgid;
    private String uniqueid;
}