package com.ks.auth;

import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;

// TestController.java
@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
public class TestController {

    @GetMapping("/public")
    public ResponseEntity<String> publicEndpoint() {
        return ResponseEntity.ok("This is a public endpoint - no token required");
    }

    @GetMapping("/protected")
    public ResponseEntity<String> protectedEndpoint() {
        // Get authenticated client ID from security context
        String clientId = SecurityContextHolder.getContext()
                            .getAuthentication()
                            .getName();
        
        return ResponseEntity.ok("This is a protected endpoint - your client ID is: " + clientId);
    }

    @GetMapping("/check-token")
    public ResponseEntity<Map<String, Object>> checkTokenInfo(
            @RequestHeader("Authorization") String authHeader) {
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String token = authHeader.substring(7);
        Claims claims = Jwts.parser()
                        .verifyWith(getSigningKey())
                        .build()
                        .parseSignedClaims(token)
                        .getPayload();

        Map<String, Object> response = new HashMap<>();
        response.put("clientId", claims.getSubject());
        response.put("issuedAt", claims.getIssuedAt());
        response.put("expiration", claims.getExpiration());
        response.put("message", "Token is valid");

        return ResponseEntity.ok(response);
    }

    // Helper method to get signing key (same as in JwtUtils)
    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }

    @Value("${jwt.secret}")
    private String jwtSecret;
}