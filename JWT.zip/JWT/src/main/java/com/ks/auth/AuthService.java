package com.ks.auth;

import org.springframework.stereotype.Service;

@Service
public class AuthService {

    public boolean isValidClient(AuthRequest request) {
        // Implement your actual client validation logic here
        return request.getClient_id() != null && 
               request.getClient_secret() != null &&
               request.getOrgid() != null &&
               request.getUniqueid() != null;
    }
}