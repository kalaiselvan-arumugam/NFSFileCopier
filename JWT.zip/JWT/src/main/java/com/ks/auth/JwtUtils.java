package com.ks.auth;

import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;

//JwtUtils.java
//JwtUtils.java
@Component
@RequiredArgsConstructor
public class JwtUtils {
 
 @Value("${jwt.secret}")
 private String secret;
 
 @Value("${jwt.expiration}")
 private int expiration;

 public String generateToken(String clientId) {
     return Jwts.builder()
             .subject(clientId)
             .issuedAt(new Date())
             .expiration(new Date(System.currentTimeMillis() + expiration * 1000L))
             .signWith(getSigningKey(), Jwts.SIG.HS256)
             .compact();
 }

 public boolean validateToken(String token) {
     try {
         getJwtParser().parseSignedClaims(token);
         return true;
     } catch (Exception e) {
         return false;
     }
 }

 public String getClientIdFromToken(String token) {
     return getJwtParser()
             .parseSignedClaims(token)
             .getPayload()
             .getSubject();
 }

 private JwtParser getJwtParser() {
     return Jwts.parser()
             .verifyWith(getSigningKey())
             .build();
 }

 private SecretKey getSigningKey() {
     return Keys.hmacShaKeyFor(secret.getBytes());
 }

 public int getExpiration() {
     return expiration;
 }
}